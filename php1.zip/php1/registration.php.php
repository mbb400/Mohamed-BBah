<?php
session_start();
header('location:login.php');
$con = mysqli_connect('localhost', 'root', '12345678');
mysqli_select_db($con, 'form');
$name = $_POST['formtable'];
$pass = $_POST['password'];

$s= "select * from formtable where name='$name'";

$result = mysqli_query($con, $s);
$num = mysqli_num_rows($result);

if($num == 1){
    echo "Usename Already Taken";
}
else{
    $reg="insert into formtable(name, password) values('$name', '$pass')"; 
    mysqli_query($con, $reg);
    echo "registration successful";
}

?>